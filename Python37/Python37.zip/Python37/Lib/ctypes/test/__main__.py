from ctypes.test import load_tests
import unittest

unittest.main()
