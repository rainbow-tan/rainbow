import numpy as np
arr = [0, 80, 10, 15]
#求方差
arr_var = np.var(arr)
#求标准差
arr_std = np.std(arr,ddof=1)
print("方差为：%f" % arr_var)
print("标准差为:%f" % arr_std)